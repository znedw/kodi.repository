# service.defaultplaybackspeed.matrix

Set the default playback speed when videos start playing.

Be sure to enable "Sync playback to display", under Settings -> Player -> Videos.
