#!/usr/bin/python

from playbackspeed import *

PlaybackSpeedRunner()
